#pragma once

#include <stdexcept>

#include <vulkan/vulkan.h>

#include <../../external/imgui/imgui.h>
#include <../../external/imgui/backends/imgui_impl_glfw.h>
#include <../../external/imgui/backends/imgui_impl_vulkan.h>

#include "../../src/lavac.h"

namespace LavaEngine
{
    class Inspector
    {
    public:
        explicit Inspector(UserGame& application)
            : m_application(application)
        {
            initialize();
        }

        ~Inspector()
        {
            shutdown();
        }

        Inspector(const Inspector&) = delete;
        Inspector& operator=(const Inspector&) = delete;

        void inspect()
        {
            while (true)
            {
                beginFrame();

                draw();

                ImGui::Render();

                if (m_application.step())
                    break;
            }
        }

    private:
        void initialize()
        {
            vulkan =
                m_application.application()
                             .findFramework<VulkanRenderer>();

            if (!vulkan)
            {
                throw std::runtime_error(
                    "Inspector requires VulkanRenderer"
                );
            }

            IMGUI_CHECKVERSION();

            ImGui::CreateContext();

            ImGuiIO& io = ImGui::GetIO();

            io.ConfigFlags |=
                ImGuiConfigFlags_DockingEnable;

            if (!ImGui_ImplGlfw_InitForVulkan(
                vulkan->window().getGlfwWindow(),
                true))
            {
                ImGui::DestroyContext();

                throw std::runtime_error(
                    "Failed to initialize ImGui GLFW backend"
                );
            }

            ImGui_ImplVulkan_InitInfo initInfo{};

            initInfo.Instance =
                vulkan->instance().native();

            initInfo.PhysicalDevice =
                vulkan->device().physical();

            initInfo.Device =
                vulkan->device().native();

            initInfo.QueueFamily =
                vulkan->device().getQueueFamily(
                    QueueType::GRAPHICS
                );

            initInfo.Queue =
                vulkan->device()
                      .getQueue(QueueType::GRAPHICS)
                      .native();

            initInfo.DescriptorPool =
                vulkan->descriptorPool().native();

            initInfo.MinImageCount = 2;

            initInfo.ImageCount =
                vulkan->swapChain().imageCount();

            initInfo.PipelineInfoMain.RenderPass =
                vulkan->renderPass().native();

            initInfo.PipelineInfoMain.Subpass = 0;

            initInfo.PipelineInfoMain.MSAASamples =
                VK_SAMPLE_COUNT_1_BIT;

            if (!ImGui_ImplVulkan_Init(&initInfo))
            {
                ImGui_ImplGlfw_Shutdown();
                ImGui::DestroyContext();

                throw std::runtime_error(
                    "Failed to initialize ImGui Vulkan backend"
                );
            }

            std::cout
                << "RendererHasTextures: "
                << ((ImGui::GetIO().BackendFlags &
                        ImGuiBackendFlags_RendererHasTextures)
                        ? "YES"
                        : "NO")
                << '\n';

            vulkan->setOverlayCallback(
                [](CommandBuffer& commandBuffer)
                {
                    ImDrawData* data = ImGui::GetDrawData();

                    if (!data)
                    {
                        std::cerr << "NO ImGui DrawData\n";
                        return;
                    }

                    std::cerr
                        << "ImGui: "
                        << data->CmdListsCount
                        << " lists, "
                        << data->TotalVtxCount
                        << " vertices, "
                        << data->TotalIdxCount
                        << " indices\n";

                    ImGui_ImplVulkan_RenderDrawData(
                        data,
                        commandBuffer.native()
                    );
                }
            );
        }

        void beginFrame()
        {
            ImGui_ImplVulkan_NewFrame();

            ImGui_ImplGlfw_NewFrame();

            ImGui::NewFrame();
        }

        void draw()
        {
            ImGui::DockSpaceOverViewport();

            ImGui::ShowDemoWindow();

            drawVulkanPanel();
        }


        void drawVulkanPanel()
        {
            if (!vulkan)
                return;

            if (ImGui::Begin("Vulkan"))
            {
                ImGui::Text(
                    "Vulkan Framework"
                );

                ImGui::Separator();

                ImGui::Text(
                    "Window: %dx%d",
                    vulkan->window().getWidth(),
                    vulkan->window().getHeight()
                );

                ImGui::Text(
                    "Window title: %s",
                    vulkan->getName().c_str()
                );

                ImGui::Text(
                    "Swapchain images: %u",
                    vulkan->swapChain().imageCount()
                );
            }

            ImGui::End();
        }

        void shutdown()
        {
            if (!ImGui::GetCurrentContext())
                return;

            /*
             * The Vulkan backend may still have GPU resources in use.
             *
             * Make sure all rendering has completed before destroying
             * ImGui's Vulkan objects.
             */
            if (vulkan)
            {
                vkDeviceWaitIdle(
                    vulkan->device().native()
                );

                vulkan->clearOverlayCallback();
            }

            ImGui_ImplVulkan_Shutdown();

            ImGui_ImplGlfw_Shutdown();

            ImGui::DestroyContext();

            vulkan = nullptr;
        }

    private:
        UserGame& m_application;

        VulkanRenderer* vulkan = nullptr;
    };
}
